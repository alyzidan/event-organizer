export const config = {
  apiKey: 'AIzaSyA9YZEMdoiV8_ay87ordsQo0jy1A0Vy2bw',
  authDomain: 'devmeeting-b3694.firebaseapp.com',
  databaseURL: 'https://devmeeting-b3694.firebaseio.com',
  projectId: 'devmeeting-b3694',
  storageBucket: '',
  messagingSenderId: ''
}
